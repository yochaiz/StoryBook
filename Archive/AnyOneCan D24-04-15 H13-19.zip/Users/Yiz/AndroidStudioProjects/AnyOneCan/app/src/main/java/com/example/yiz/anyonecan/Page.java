package com.example.yiz.anyonecan;

/**
 * Created by Yiz on 23/04/2015.
 */
public class Page {
    //private Class self;
    private Class previous;
    private Class next;

    Page(Class prev, Class next) {
        //this.self = self;
        this.previous = prev;
        this.next = next;
    }

//    public Class getSelf() {
//        return self;
//    }

    public Class getPrevious() {
        return previous;
    }

    public Class getNext() {
        return next;
    }
}
