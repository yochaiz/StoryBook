package com.example.yiz.anyonecan;

import android.os.Bundle;
import android.widget.TextView;


public class Page1Activity extends BaseActivity {

    private TextView tv_three = null;
    private TextView tv_bobby = null;
    private TextView tv_children_left = null;
    private TextView tv_children_right = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page1);

        setPage(R.layout.activity_page1);

        setClickableTextView(tv_three, R.id.tv_p1_three, R.raw.b_1_3_1);
        setClickableTextView(tv_bobby, R.id.tv_p1_bobby, R.raw.b_1_3_2);
        setClickableTextView(tv_children_left, R.id.tv_p1_children_left, R.raw.b_1_3_3);
        setClickableTextView(tv_children_right, R.id.tv_p1_children_right, R.raw.b_1_3_3);
    }

}
