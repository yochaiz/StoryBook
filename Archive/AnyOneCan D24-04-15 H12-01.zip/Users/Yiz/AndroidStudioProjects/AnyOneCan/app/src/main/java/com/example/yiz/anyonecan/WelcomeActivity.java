package com.example.yiz.anyonecan;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.Timer;
import java.util.TimerTask;


public class WelcomeActivity extends ActionBarActivity {

    private MediaPlayer mp = null;
    private Intent intent = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        intent = new Intent(this,Page1Activity.class);
        mp = MediaPlayer.create(this, R.raw.welcome);
        mp.setOnCompletionListener(mpComplete);
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                mp.start();
            }
        };
        long delay = 500;
        timer.schedule(task, delay);


    }

    private MediaPlayer.OnCompletionListener mpComplete = new MediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(MediaPlayer mp) {
            startActivity(intent);
        }
    };
}
