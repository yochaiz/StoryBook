package com.example.yiz.anyonecan;

import android.content.Intent;
import android.media.MediaPlayer;
import android.provider.MediaStore;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


public class Page1Activity extends BaseActivity {

    private TextView tv_three = null;
    private TextView tv_bobby = null;
    private TextView tv_children_left = null;
    private TextView tv_children_right = null;
    private MediaPlayer mp_three = null;
    private MediaPlayer mp_bobby = null;
    private MediaPlayer mp_children = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page1);

        setPage(R.layout.activity_page1);

        tv_three = (TextView) findViewById(R.id.tv_three);
        mp_three = MediaPlayer.create(this, R.raw.b_1_3_1);
        tv_three.setOnClickListener(threeClick);
        tv_bobby = (TextView) findViewById(R.id.tv_bobby);
        mp_bobby = MediaPlayer.create(this, R.raw.b_1_3_2);
        tv_bobby.setOnClickListener(bobbyClick);
        tv_children_left = (TextView) findViewById(R.id.tv_children_left);
        tv_children_right = (TextView) findViewById(R.id.tv_children_right);
        mp_children = MediaPlayer.create(this, R.raw.b_1_3_3);
        tv_children_right.setOnClickListener(childrenClick);
        tv_children_left.setOnClickListener(childrenClick);
    }

    private View.OnClickListener threeClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            mp_three.start();
        }
    };

    private View.OnClickListener bobbyClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            mp_bobby.start();
        }
    };

    private View.OnClickListener childrenClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            mp_children.start();
        }
    };
}
