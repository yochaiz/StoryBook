package com.example.yiz.anyonecan;

import android.os.Bundle;


public class Page3Activity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page3);

        setPage(R.layout.activity_page3);
    }
}
